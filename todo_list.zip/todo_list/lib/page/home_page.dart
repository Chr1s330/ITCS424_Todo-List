import 'package:flutter/material.dart';
import 'package:chat/main.dart';

class MyHomePage extends StatefulWidget {
  const MyHomePage({Key? key, required this.title}) : super(key: key);

  final String title;

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  int selectedIndex = 0;
  List<String> list = [];
  List<String> completedList = [];
  TextEditingController controller = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.title),
      ),
      bottomNavigationBar: BottomNavigationBar(
        backgroundColor: Theme.of(context).primaryColor,
        unselectedItemColor: Colors.white.withOpacity(0.7),
        selectedItemColor: Colors.white,
        currentIndex: selectedIndex,
        onTap: (index) => setState(() {
          selectedIndex = index;
          setState(() {});
        }),
        items: const [
          BottomNavigationBarItem(
            icon: Icon(Icons.fact_check_outlined),
            label: 'Todos',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.done, size: 28),
            label: 'Completed',
          ),
        ],
      ),
      body: _buildBody(),
    );
  }

  Widget _buildBody() {
    return selectedIndex == 0 ? _buildTodos() : _buildCompleted();
  }

  Widget _buildTodos() {
    return Column(
      children: [
        Expanded(
          child: ListView.builder(
            itemCount: list.length,
            itemBuilder: (context, index) {
              return Column(
                children: [
                  Row(
                    children: [
                      Expanded(
                        child: InkWell(
                          onLongPress: () {
                            setState(() {
                              list.removeAt(index);
                            });
                          },
                          child: Container(
                            height: 60,
                            alignment: Alignment.centerLeft,
                            child: Text(list[index]),
                          ),
                        ),
                      ),
                      Checkbox(
                        value: false,
                        onChanged: (value) {
                          setState(() {
                            completedList.add(list.removeAt(index));
                          });
                        },
                      ),
                    ],
                  ),
                  Container(
                    height: 0.5,
                    color: Colors.black26,
                  ),
                ],
              );
            },
          ),
        ),
        Container(
          color: Colors.black12,
          padding: const EdgeInsets.only(top: 10, left: 15, right: 15, bottom: 15),
          child: Row(
            children: [
              Expanded(
                child: TextField(
                  controller: controller,
                ),
              ),
              const SizedBox(
                width: 10,
              ),
              ElevatedButton(
                onPressed: () {
                  String text = controller.text;
                  if (text.isEmpty) {
                    return;
                  }
                  setState(() {
                    list.add(text);
                    controller.text = "";
                  });
                },
                child: const Text('Add'),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildCompleted() {
    return ListView.builder(
      itemCount: completedList.length,
      itemBuilder: (context, index) {
        return Column(
          children: [
            InkWell(
              onLongPress: () {
                setState(() {
                  completedList.removeAt(index);
                });
              },
              child: Container(
                height: 60,
                alignment: Alignment.centerLeft,
                child: Text(completedList[index]),
              ),
            ),
            Container(
              height: 0.5,
              color: Colors.black26,
            ),
          ],
        );
      },
    );
  }
}
